#Librerias
import matplotlib.pyplot as plt
import numpy as np
import random

#generarExcel con datos
def generarExcel(x,y):
    import xlsxwriter
    libro = xlsxwriter.Workbook('Datos.xlsx');
    hoja = libro.add_worksheet();
    fila = 0;
    columna = 0;
    for dato in x:
        hoja.write(fila,columna,dato);
        fila += 1;
    columna = 1;
    fila=0;
    for dato in y:
        hoja.write(fila,columna,dato);
        fila += 1;
    libro.close();

#Función para generar randomicamente numeros
def arregloRand(largo,min,max):
    rand = np.random.rand(largo)
    retorno = []
    for num in rand:
        retorno.append(num*(max-min)+min)
    return retorno;

#Definir los tiempos
def definirtiempo(hora,min,seg,largo):
    retorno=[]
    for i in np.arange(largo):
        seg+=1
        if seg==60:
            min+=1
            seg=0
        if min==60:
            hora+=1
            min=0
        if hora==24:
            hora=0
        retorno.append(str(hora)+":"+str(min)+":"+str(seg))
    return retorno;

#Generar los textos segun cuantos quiera
def generarTextos(lista,cantidad):
    textos = []
    i = 0
    paso = len(lista)/cantidad
    for t in lista:
        i+=1
        if i%paso<1:
            textos.append(t)
    return textos

#Sacar la media
def media(lista):
    return np.sum(lista) / len(lista)

#Sacar la desviacion
def desviacion(lista):
    return np.std(lista)

#Dibujar la linea de orientacion
def dibujarlinea(valor, orientacion, x, nombre, color):
    x=sorted(x)
    if(orientacion == 1):
        plt.plot([0,len(x)-1],[valor,valor],color,label = nombre)
    if(orientacion == 2):
        plt.plot([valor,valor],[0,len(x)-1],color,label = nombre)

#funcion para reconocer el patron1
def patron1(x,y,desviaciones):
    #print("x: " + )
    if y>desviaciones[4] or y<desviaciones[5]:
        print(str(y) + "Se paso de +3S o -3S en: "+x)

#funcion para reconocer el patron2
def patron2(x,y,inicio,desviaciones):
    mantiene = 0
    zonaC = 0
    i = inicio
    while i<len(y) and mantiene == 0:
        if y[i] < desviaciones[0] and y[i] > desviaciones[6]:
            zonaC += 1
        else:
            mantiene = 1
        i += 1

    if zonaC >= 9:
        print("Se mantiene en la zona C durante " + str(zonaC) + " puntos desde el punto: " + str(x))
        return inicio + zonaC
    i = inicio
    zonaC = 0
    mantiene = 0
    while i<len(y) and mantiene == 0:
        if y[i] > desviaciones[1] and y[i] < desviaciones[6]:
            a = 3
        else:
            mantiene = 1
        i += 1

    if zonaC >= 9:
        print("Se mantiene en la zona C durante " + str(zonaC) + " puntos desde el punto: " + str(x))
        return inicio + zonaC
    return inicio

#funcion para reconocer el patron3
def patron3(x,y,inicio,desviaciones):
    conta=0
    conta1=0
    mantiene=0
    mantiene1=0
    i=inicio
    while i<len(y)-1 and mantiene==0:
        if  y[i]<y[i+1]:
            conta+=1
            if conta>=3 :
                print("Se consiguio "+str(conta)+" puntos incrementando desde el punto: "+str(x))
        else:
            mantiene=1
        i+=1
    i=inicio
    while i<len(y)-1 and mantiene1==0:
        if  y[i+1]<y[i]:
            conta1+=1
            if conta1>=3:
                print("Se consiguio "+str(conta1)+"puntos decrementando desde el punto:"+str(x))
        else:
            mantiene1=1
        i+=1
    return inicio

#funcion para reconocer el patron4



#funcion para los patrones
def patrones(x,y,desviaciones):
    i=0
    p2 = 0
    p3 = 0
    for n in x:
        patron1(x[i],y[i],desviaciones)
        if i >= p2:
            p2 = patron2(x[i],y,i,desviaciones)
            print(p2)
        if i>=p3:
            p3=patron3(x[i],y,i,desviaciones)
            print(p3)
        i+=1



tiempos=definirtiempo(4,20,43,100)
temperaturas=arregloRand(100,2000,4000)
plt.style.use("dark_background")
plt.plot(tiempos,temperaturas,"w-")
plt.plot(tiempos,temperaturas,"ro",label="temperaturas")

mediate = media(temperaturas)
deste = desviacion(temperaturas)
s1mas=mediate+deste
s1menos=mediate-deste
s2mas=mediate+deste*2
s2menos=mediate-deste*2
s3mas=mediate+deste*3
s3menos=mediate-deste*3

dibujarlinea(mediate,1,temperaturas,"media temperaturas","b--")
dibujarlinea(s1mas,1,temperaturas,"s1+","g--")
dibujarlinea(s1menos,1,temperaturas,"s1-","g--")
dibujarlinea(s2mas,1,temperaturas,"s2+","y--")
dibujarlinea(s2menos,1,temperaturas,"s2-","y--")
dibujarlinea(s3mas,1,temperaturas,"s3+","r--")
dibujarlinea(s3menos,1,temperaturas,"s3-","r--")
desviaciones=[s1mas,s1menos,s2mas,s2menos,s3mas,s3menos,mediate]
patrones(tiempos,temperaturas,desviaciones)

plt.legend(loc="upper left")
t = (generarTextos(tiempos,10))
plt.xticks(t)
generarExcel(tiempos,temperaturas)
plt.savefig('Grafica.png');
plt.show()
